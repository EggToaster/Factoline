those file are deprecated and not for mod making due to deleted soon.
INFO:
savesys are replaced to misc.save