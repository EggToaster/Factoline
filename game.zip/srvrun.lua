require("loadapi")
mulplay.serverrun()